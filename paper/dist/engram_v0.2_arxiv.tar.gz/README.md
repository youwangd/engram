# Engram v0.2 — arXiv source

Compile with:

    xelatex main
    bibtex  main
    xelatex main
    xelatex main

or just `xelatex main` twice if you trust the bundled `main.bbl`.

Repo: https://github.com/youwangd/engram (Apache 2.0)
